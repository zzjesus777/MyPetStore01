


package org.csu.mypetstore.web.servlets;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.service.AccontService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class NewAccountServlet extends HttpServlet {
    private String username;
    private String password;
    private String repassword;
    private String email;
    private String firstName;
    private String lastName;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String zip;
    private String country;
    private String phone;
    private String favouriteCategoryId;
    private String languagePreference;
    private boolean listOption = false;
    private String[] listOptions;
    private boolean bannerOption = false;
    private String[] bannerOptions;
    private static final String VIEW_SIGNON_FORM = "/WEB-INF/jsp/account/SignonForm.jsp";
    private static final String VIEW_NEW_FORM = "/WEB-INF/jsp/account/NewAccountForm.jsp";
    private AccontService accontService;
    private Account account;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        username = request.getParameter("username");
        accontService = new AccontService();
        account = accontService.getAccount(username);
        if(account == null) {
            password = request.getParameter("password");
            repassword = request.getParameter("repassword");
            email = request.getParameter("account.email");
            firstName = request.getParameter("account.firstName");
            lastName = request.getParameter("account.lastName");
            zip = request.getParameter("account.zip");
            country = request.getParameter("account.country");
            address1 = request.getParameter("account.address1");
            address2 = request.getParameter("account.address2");
            city = request.getParameter("account.city");
            phone = request.getParameter("account.phone");
            state = request.getParameter("account.state");
            favouriteCategoryId = request.getParameter("account.favouriteCategoryId");
            languagePreference = request.getParameter("account.languagePreference");
            listOptions = request.getParameterValues("account.listOption");
            bannerOptions = request.getParameterValues("account.bannerOption");
            if (listOptions != null)
                listOption = true;
            if (bannerOptions != null)
                bannerOption = true;
            if (!username.isEmpty()&&!password.isEmpty()&&!email.isEmpty()&&!firstName.isEmpty()&&!lastName.isEmpty()&&
                    !zip.isEmpty()&&!country.isEmpty()&&!address1.isEmpty()&&!city.isEmpty()&&!phone.isEmpty()&&!state.isEmpty()
                &&password.equals(repassword)) {
                account = new Account();
                account.setUsername(username);
                account.setPassword(password);
                account.setEmail(email);
                account.setFirstName(firstName);
                account.setLastName(lastName);
                account.setZip(zip);
                account.setCountry(country);
                account.setCity(city);
                account.setAddress1(address1);
                account.setAddress2(address2);
                account.setPhone(phone);
                account.setState(state);
                account.setFavouriteCategoryId(favouriteCategoryId);
                account.setLanguagePreference(languagePreference);
                account.setListOption(listOption);
                account.setBannerOption(bannerOption);
                accontService.insertAccount(account);
                request.setAttribute("username",username);
                request.setAttribute("password",password);
                request.getRequestDispatcher(VIEW_SIGNON_FORM).forward(request, response);
            }
        }
        List<String> languages = new ArrayList<String>();
        languages.add("english");
        languages.add("japanese");

        List<String> categories = new ArrayList<String>();
        categories.add("FISH");
        categories.add("DOGS");
        categories.add("REPTILES");
        categories.add("CATS");
        categories.add("BIRDS");
        request.setAttribute("languages",languages);
        request.setAttribute("categories",categories);
        request.getRequestDispatcher(VIEW_NEW_FORM).forward(request, response);
        }
}
