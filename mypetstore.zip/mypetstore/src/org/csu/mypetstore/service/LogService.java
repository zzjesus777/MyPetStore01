package org.csu.mypetstore.service;

import org.csu.mypetstore.domain.Log;
import org.csu.mypetstore.persistence.LogDAO;
import org.csu.mypetstore.persistence.impl.LogDAOimpl;

public class LogService {
    private LogDAO logDAO;
    public LogService(){
        logDAO =new LogDAOimpl();
    }
    public void insertLog(Log log){
        logDAO.insertLog(log);
    }
}
