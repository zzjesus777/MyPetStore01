package org.csu.mypetstore.domain;

import java.util.Date;

public class Log {
    private String username = "游客";
    private String URL;
    private Date operationTime;
    private String behavior;

    public String getUsername() {
        return username;
    }

    public String getURL() {
        return URL;
    }

    public Date getOperationTime() {
        return operationTime;
    }

    public String getBehavior() {
        return behavior;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }

    public void setOperationTime(Date operationTime) {
        this.operationTime = operationTime;
    }

    public void setBehavior(String behavior) {
        this.behavior = behavior;
    }
}
