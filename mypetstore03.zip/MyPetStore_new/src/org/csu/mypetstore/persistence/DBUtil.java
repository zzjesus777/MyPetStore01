package org.csu.mypetstore.persistence;

import java.sql.*;

public class DBUtil {
    private static final String driver = "com.mysql.cj.jdbc.Driver";
    private static final String url = "jdbc:mysql://127.0.0.1:3306/mypetstore?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";//链接的mysql
    private static final String username = "root";
    private static final String password ="123456";

    public static Connection getConnection()throws Exception{
        try{
            Class.forName(driver);
            return DriverManager.getConnection(url,username,password);
        }
        catch (Exception e){
            throw e;
        }
    }

    public static void closeConnection(Connection connection)throws Exception{
        if(connection != null){
            connection.close();
        }
    }

    public static void closeStatement(Statement statement)throws Exception{
        if(statement != null){
            statement.close();
        }
    }

    public static void closePreparedStatement(PreparedStatement preparedStatement)throws Exception{
        if(preparedStatement != null){
            preparedStatement.close();
        }
    }

    public static void closeResultSet(ResultSet resultSet)throws Exception{
        if(resultSet != null){
            resultSet.close();
        }
    }

}