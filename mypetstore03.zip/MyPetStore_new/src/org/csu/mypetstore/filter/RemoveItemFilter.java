package org.csu.mypetstore.filter;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.domain.Log;
import org.csu.mypetstore.service.LogService;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

public class RemoveItemFilter implements Filter {
    private LogService logService;
    private Log log;

    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        HttpServletRequest httpServletRequest = (HttpServletRequest)req;
        HttpSession session = httpServletRequest.getSession();
        Account account = (Account) session.getAttribute("account");
        String ID = (String) httpServletRequest.getParameter("workingItemId");
        logService = new LogService();
        log = new Log();
        if(account!=null)
            log.setUsername(account.getUsername());
        log.setURL(httpServletRequest.getRequestURI());
        log.setBehavior("将"+ID+"移除购物车");
        Date time = new Date();
        log.setOperationTime(time);
        logService.insertLog(log);
        chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
