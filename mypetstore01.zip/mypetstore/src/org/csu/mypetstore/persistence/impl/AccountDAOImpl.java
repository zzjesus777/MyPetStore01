package org.csu.mypetstore.persistence.impl;

import org.csu.mypetstore.domain.Account;
import org.csu.mypetstore.persistence.AccountDAO;
import org.csu.mypetstore.persistence.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AccountDAOImpl implements AccountDAO {
    private static final String GET_ACCOUNT_BY_USERNAME = "SELECT          SIGNON.USERNAME,          ACCOUNT.EMAIL,          ACCOUNT.FIRSTNAME,          ACCOUNT.LASTNAME,          ACCOUNT.STATUS,          ACCOUNT.ADDR1 AS address1,          ACCOUNT.ADDR2 AS address2,          ACCOUNT.CITY,          ACCOUNT.STATE,          ACCOUNT.ZIP,          ACCOUNT.COUNTRY,          ACCOUNT.PHONE,          PROFILE.LANGPREF AS languagePreference,          PROFILE.FAVCATEGORY AS favouriteCategoryId,          PROFILE.MYLISTOPT AS listOption,          PROFILE.BANNEROPT AS bannerOption,          BANNERDATA.BANNERNAME    FROM ACCOUNT, PROFILE, SIGNON, BANNERDATA    WHERE ACCOUNT.USERID = ?      AND SIGNON.USERNAME = ACCOUNT.USERID      AND PROFILE.USERID = ACCOUNT.USERID      AND PROFILE.FAVCATEGORY = BANNERDATA.FAVCATEGORY";

    @Override
    public Account getAccountByUsername(String username) {
        Account account = null;
        try{
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(GET_ACCOUNT_BY_USERNAME);
            preparedStatement.setString(1,username);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                account = new Account();
                account.setEmail(resultSet.getString(1));
                account.setFirstName(resultSet.getString(2));
                account.setLastName(resultSet.getString(3));
                account.setStatus(resultSet.getString(4));
                account.setAddress1(resultSet.getString(5));
                account.setAddress2(resultSet.getString(6));
                account.setCity(resultSet.getString(7));
                account.setState(resultSet.getString(8));
                account.setZip(resultSet.getString(9));
                account.setCountry(resultSet.getString(10));
                account.setPhone(resultSet.getString(11));
                account.setLanguagePreference(resultSet.getString(12));
                account.setFavouriteCategoryId(resultSet.getString(13));
                account.setListOption(resultSet.getBoolean(14));
                account.setBannerOption(resultSet.getBoolean(15));
                account.setBannerName(resultSet.getString(16));
            }
            DBUtil.closeResultset(resultSet);
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        }catch (Exception e){
            e.printStackTrace();
        }
        return account;
    }

    private static final String GET_ACCOUNT_BY_USERNAME_AND_PASSWORD = "SELECT       SIGNON.USERNAME,   ACCOUNT.EMAIL,       ACCOUNT.FIRSTNAME,       ACCOUNT.LASTNAME,       ACCOUNT.STATUS,       ACCOUNT.ADDR1 AS address1,       ACCOUNT.ADDR2 AS address2,       ACCOUNT.CITY,       ACCOUNT.STATE,       ACCOUNT.ZIP,       ACCOUNT.COUNTRY,       ACCOUNT.PHONE,       PROFILE.LANGPREF AS languagePreference,       PROFILE.FAVCATEGORY AS favouriteCategoryId,       PROFILE.MYLISTOPT AS listOption,       PROFILE.BANNEROPT AS bannerOption,       BANNERDATA.BANNERNAME     FROM ACCOUNT, PROFILE, SIGNON, BANNERDATA     WHERE ACCOUNT.USERID = ?       AND SIGNON.PASSWORD = ?       AND SIGNON.USERNAME = ACCOUNT.USERID       AND PROFILE.USERID = ACCOUNT.USERID       AND PROFILE.FAVCATEGORY = BANNERDATA.FAVCATEGORY";

    @Override
    public Account getAccountByUsernameAndPassword(String username, String password) {
        Account account = null;
        try{
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(GET_ACCOUNT_BY_USERNAME_AND_PASSWORD);
            preparedStatement.setString(1,username);
            preparedStatement.setString(2,password);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                account = new Account();
                account.setEmail(resultSet.getString(1));
                account.setFirstName(resultSet.getString(2));
                account.setLastName(resultSet.getString(3));
                account.setStatus(resultSet.getString(4));
                account.setAddress1(resultSet.getString(5));
                account.setAddress2(resultSet.getString(6));
                account.setCity(resultSet.getString(7));
                account.setState(resultSet.getString(8));
                account.setZip(resultSet.getString(9));
                account.setCountry(resultSet.getString(10));
                account.setPhone(resultSet.getString(11));
                account.setLanguagePreference(resultSet.getString(12));
                account.setFavouriteCategoryId(resultSet.getString(13));
                //account.setListOption(resultSet.getBoolean(14));
                account.setBannerOption(resultSet.getBoolean(15));
                account.setBannerName(resultSet.getString(16));
            }
            DBUtil.closeResultset(resultSet);
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        }catch (Exception e){
            e.printStackTrace();
        }
        return account; 
    }

    private static final String INSERT_ACCOUNT = "INSERT INTO ACCOUNT       (EMAIL, FIRSTNAME, LASTNAME, STATUS, ADDR1, ADDR2, CITY, STATE, ZIP, COUNTRY, PHONE, USERID) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";

    @Override
    public void insertAccount(Account account) {
        try {
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ACCOUNT);
            preparedStatement.setString(1,account.getEmail());
            preparedStatement.setString(2,account.getFirstName());
            preparedStatement.setString(3,account.getLastName());
            preparedStatement.setString(4,account.getStatus());
            preparedStatement.setString(5,account.getAddress1());
            preparedStatement.setString(6,account.getAddress2());
            preparedStatement.setString(7,account.getCity());
            preparedStatement.setString(8,account.getState());
            preparedStatement.setString(9,account.getZip());
            preparedStatement.setString(10,account.getCountry());
            preparedStatement.setString(11,account.getPhone());
            preparedStatement.setString(12,account.getUsername());
            preparedStatement.executeUpdate();
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final String UPDATE_ACCOUNT = "UPDATE ACCOUNT SET EMAIL = ?,FIRSTNAME = ?,LASTNAME = ?,STATUS = ?,ADDR1 = ?,ADDR2 = ?,CITY = ?,STATE = ?,ZIP = ?,COUNTRY = ?, PHONE = ? WHERE USERID = ?";

    @Override
    public void updateAccount(Account account) {
        try{
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_ACCOUNT);
            preparedStatement.setString(1,account.getEmail());
            preparedStatement.setString(2,account.getFirstName());
            preparedStatement.setString(3,account.getLastName());
            preparedStatement.setString(4,account.getStatus());
            preparedStatement.setString(5,account.getAddress1());
            preparedStatement.setString(6,account.getAddress2());
            preparedStatement.setString(7,account.getCity());
            preparedStatement.setString(8,account.getState());
            preparedStatement.setString(9,account.getZip());
            preparedStatement.setString(10,account.getCountry());
            preparedStatement.setString(11,account.getPhone());
            preparedStatement.setString(12,account.getUsername());
            preparedStatement.executeUpdate();
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static final String UPDATE_PROFILE = "  UPDATE PROFILE SET       LANGPREF = ?,       FAVCATEGORY = ?     WHERE USERID = ?";

    @Override
    public void updateProfile(Account account) {
        try {
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_PROFILE);
            preparedStatement.setString(1,account.getLanguagePreference());
            preparedStatement.setString(2,account.getFavouriteCategoryId());
            preparedStatement.setString(3,account.getUsername());
            preparedStatement.executeUpdate();
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final String INSERT_PROFILE = "INSERT INTO PROFILE (LANGPREF, FAVCATEGORY, USERID) VALUES (?,?,?)";

    @Override
    public void insertProfile(Account account) {
        try {
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_PROFILE);
            preparedStatement.setString(1,account.getLanguagePreference());
            preparedStatement.setString(2,account.getFavouriteCategoryId());
            preparedStatement.setString(3,account.getUsername());
            preparedStatement.executeUpdate();
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final String UPDATE_SIGN_ON = " UPDATE SIGNON SET PASSWORD = ?  WHERE USERNAME = ?";

    @Override
    public void updateSignOn(Account account) {
        try {
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_SIGN_ON);
            preparedStatement.setString(1,account.getPassword());
            preparedStatement.setString(2,account.getUsername());
            preparedStatement.executeUpdate();
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static final String INSERT_SIGN_ON = "INSERT INTO SIGNON (PASSWORD,USERNAME) VALUES (?,?)";

    @Override
    public void insertSignOn(Account account) {
        try {
            Connection connection = DBUtil.getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SIGN_ON);
            preparedStatement.setString(1,account.getPassword());
            preparedStatement.setString(2,account.getUsername());
            preparedStatement.executeUpdate();
            DBUtil.closePreparedStatement(preparedStatement);
            DBUtil.closeConnection(connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
